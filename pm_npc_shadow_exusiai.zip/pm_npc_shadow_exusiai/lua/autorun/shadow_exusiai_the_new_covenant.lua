--Add Playermodel
player_manager.AddValidModel( "Shadow Exusiai", "models/PM/Shadow_Exusiai_the_New_Covenant_pm.mdl" )                         --PM模型
player_manager.AddValidHands( "Shadow Exusiai", "models/arms/Shadow_Exusiai_the_new_covenant_arms.mdl", 0, "00000000" )      --PM手模

local Category = "Exusiai_the_new_covenant"                                                                        --NPC MOD分类

local NPC = 
{
	Name = "Shadow_Exusiai(Friendly)",                                                            --友好NPC名字
	Class = "npc_citizen", 
	Health = "100",                                                                    --NPC血量
	KeyValues = { citizentype = 4 }, 
	Model = "models/NPC/Shadow_Exusiai_the_new_covenant_npc.mdl",                                                  --友好NPC模型
	Weapons = { "weapon_ar2","weapon_smg1"},                                           --NPC出生自带武器
	Category = Category
}

list.Set( "NPC", "Shadow_Exusiai_friendly", NPC )

local NPC =
{
	Name = "Shadow_Exusiai(Enemy)",                                                                --敌人NPC名字
	Class = "npc_combine_s",
	Health = "100",
	Numgrenades = "4",
	Model = "models/NPC/Shadow_Exusiai_the_new_covenant_npc.mdl",                                                  --敌人NPC模型
	Weapons = { "weapon_ar2","weapon_smg1"},
	Category = Category
}

list.Set( "NPC", "Shadow_Exusiai_enemy", NPC )
